<?php

namespace App\Controllers;

use App\Core\AbstractController;
use App\Core\Interfaces\IHeader;
use App\Core\EntityManager;
use App\Entity\Tasks;

class DetailController extends AbstractController implements IHeader
{
    protected $em;
    protected $tasksRepository;

    public function __construct()
    {
        $this->setEm((new EntityManager())->get());
        $this->setTasksRepository($this->getEm()->getRepository(Tasks::class));
    }

    public function showDetail($id)
    {
        
            $this->setEm((new EntityManager())->get());
            $this->setTasksRepository($this->getEm()->getRepository(Tasks::class));

        $task = $this->getTasksRepository()->find($id);
        print_r($task);
        if ($task) {
            $this->render("update.html.twig", ["task" => $task]);
        }
    }

    /**
     * Redirects the location to the url passed by parameter.
     *
     * @param  String $url
     * @return void
     */
    public function redirectTo($url)
    {
        header("location: " . $url);
    }

    /**
     * Get the value of em
     */
    public function getEm()
    {
        return $this->em;
    }

    /**
     * Set the value of em
     *
     * @return  self
     */
    public function setEm($em)
    {
        $this->em = $em;

        return $this;
    }

    /**
     * Get the value of tasksRepository
     */
    public function getTasksRepository()
    {
        return $this->tasksRepository;
    }

    /**
     * Set the value of tasksRepository
     *
     * @return  self
     */
    public function setTasksRepository($tasksRepository)
    {
        $this->tasksRepository = $tasksRepository;

        return $this;
    }
}
