<?php

namespace App\Core\Interfaces;

interface IHeader
{
    public function redirectTo($url);
}
